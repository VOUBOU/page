<?php
//connexion a la bdd 
try
 {
 $bdd = new PDO("mysql:host=localhost;dbname=gestion_de_page", "root", "");
 $bdd ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 }
 catch(Exception $e)
 {
  die("Une érreur a été trouvé : " . $e->getMessage());
 }
 $bdd->query("SET NAMES UTF8");
 




?>