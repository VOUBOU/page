<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="style.css" />
        <title>electro shop </title>
    </head>

    <body>
        <header>
            <h1>Electro</h1>

            <label for="site-search">Sit de recherche:</label>
            <input type="search" id="site-search" name="q"
            aria-label="Search through site content">

            <button>Search</button>
        </header>
        <h1>Iphone xr </h1>
        <img src="https://23.jpg" />
        </body>
</html>