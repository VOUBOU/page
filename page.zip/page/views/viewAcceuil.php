<?php 
foreach ($articles as $article):
?>
<h2>
<?= $article->description() ?>
</h2>

<?php endforeach ?>